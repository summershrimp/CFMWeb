<?php
// database host
$db_host   = "127.0.0.1:3306";

// database name
$db_name   = "carryforme";

// database username
$db_user   = "root";

// database password
$db_pass   = "ZYB941023";

// table prefix
$prefix    = "cfm_";

$timezone    = "Asia/Shanghai";

$cookie_path    = "/";

$cookie_domain    = "";

$session = "1440";

define('CFM_CHARSET','utf-8');

define('ADMIN_PATH','admin');

define('AUTH_KEY', 'this is a key');

define('OLD_AUTH_KEY', '');

define('API_TIME', '');

define('CHANNEL_API_KEY','DGv8TZhmZyGglKQojU2Uo6BI');

define('CHANNEL_SECRET_KEY','8okSd8tTmpU8c9KVNDXGudiRiS3PlhSB');

define('SMS_APP_ID',"391791200000035308");

define('SMS_APP_SEC',"bea5b8c7025d6357d2d6c151ec017c3e");

?>

