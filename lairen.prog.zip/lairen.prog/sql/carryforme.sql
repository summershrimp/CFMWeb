-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2014 年 05 月 27 日 13:12
-- 服务器版本: 5.6.12-log
-- PHP 版本: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `carryforme`
--
CREATE DATABASE IF NOT EXISTS `carryforme` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `carryforme`;

-- --------------------------------------------------------

--
-- 表的结构 `cfm_admin_log`
--

CREATE TABLE IF NOT EXISTS `cfm_admin_log` (
  `log_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `log_time` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `log_info` varchar(255) NOT NULL DEFAULT '',
  `ip_address` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`log_id`),
  KEY `log_time` (`log_time`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `cfm_admin_privilage`
--

CREATE TABLE IF NOT EXISTS `cfm_admin_privilage` (
  `action_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned DEFAULT '0',
  `action_code` int(11) NOT NULL,
  `relevance` int(11) NOT NULL,
  PRIMARY KEY (`action_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `cfm_admin_users`
--

CREATE TABLE IF NOT EXISTS `cfm_admin_users` (
  `admin_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(32) NOT NULL,
  `admin_pass` varchar(32) NOT NULL,
  `salt` int(4) DEFAULT NULL,
  `email` varchar(64) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `privilage` varchar(20) DEFAULT NULL,
  `last_login` int(11) DEFAULT NULL,
  `last_ip` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`admin_id`),
  KEY `admin_id` (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='storage administrators' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `cfm_admin_users`
--

INSERT INTO `cfm_admin_users` (`admin_id`, `admin_name`, `admin_pass`, `salt`, `email`, `phone`, `add_time`, `privilage`, `last_login`, `last_ip`) VALUES
(1, 'xm1994', '5adfa40b5676e0a44a5c5bee0c6a85da', 2812, '', '', 0, NULL, NULL, '127.0.0.1');

-- --------------------------------------------------------

--
-- 表的结构 `cfm_ants`
--

CREATE TABLE IF NOT EXISTS `cfm_ants` (
  `ant_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(60) NOT NULL DEFAULT '',
  `ant_name` varchar(60) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `ant_real_name` varchar(60) NOT NULL DEFAULT '',
  `question` varchar(255) NOT NULL DEFAULT '',
  `answer` varchar(255) NOT NULL DEFAULT '',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `birthday` date NOT NULL DEFAULT '0000-00-00',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_ip` varchar(15) NOT NULL DEFAULT '',
  `pic_url` text,
  `salt` varchar(10) DEFAULT NULL,
  `mobile_phone` varchar(20) NOT NULL,
  `is_validated` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `passwd_answer` varchar(255) DEFAULT NULL,
  `last_lon` varchar(20) NOT NULL,
  `last_lat` varchar(20) NOT NULL,
  `ant_online` tinyint(1) DEFAULT NULL,
  `channel_id` varchar(32) NOT NULL,
  `channel_user_id` varchar(32) NOT NULL,
  PRIMARY KEY (`ant_id`),
  UNIQUE KEY `ant_name` (`ant_name`),
  UNIQUE KEY `ant_id` (`ant_id`),
  UNIQUE KEY `email_2` (`email`),
  UNIQUE KEY `mobile_phone` (`mobile_phone`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `cfm_ants`
--

INSERT INTO `cfm_ants` (`ant_id`, `email`, `ant_name`, `password`, `ant_real_name`, `question`, `answer`, `sex`, `birthday`, `reg_time`, `last_login`, `last_time`, `last_ip`, `pic_url`, `salt`, `mobile_phone`, `is_validated`, `passwd_answer`, `last_lon`, `last_lat`, `ant_online`, `channel_id`, `channel_user_id`) VALUES
(1, '', 'xm1994', 'e10adc3949ba59abbe56e057f20f883e', '', '', '', 0, '0000-00-00', 0, 0, '0000-00-00 00:00:00', '211.65.108.22', NULL, NULL, '', 0, NULL, '', '', 0, 'xxxxxxxxxxxx', 'XXXXXXXXXXXXXXXXXXXXXXXXX');

-- --------------------------------------------------------

--
-- 表的结构 `cfm_ants_log`
--

CREATE TABLE IF NOT EXISTS `cfm_ants_log` (
  `log_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `log_time` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `log_info` varchar(255) NOT NULL DEFAULT '',
  `ip_address` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`log_id`),
  KEY `log_time` (`log_time`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `cfm_customers`
--

CREATE TABLE IF NOT EXISTS `cfm_customers` (
  `user_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(60) NOT NULL DEFAULT '',
  `user_name` varchar(60) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `question` varchar(255) NOT NULL DEFAULT '',
  `answer` varchar(255) NOT NULL DEFAULT '',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `birthday` date NOT NULL DEFAULT '0000-00-00',
  `pay_points` int(10) unsigned NOT NULL DEFAULT '0',
  `rank_points` int(10) unsigned NOT NULL DEFAULT '0',
  `address_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_ip` varchar(15) NOT NULL DEFAULT '',
  `visit_count` smallint(5) unsigned NOT NULL DEFAULT '0',
  `salt` varchar(10) DEFAULT NULL,
  `flag` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `alias` varchar(60) NOT NULL,
  `qq` varchar(20) NOT NULL,
  `mobile_phone` varchar(20) DEFAULT NULL,
  `is_validated` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `passwd_question` varchar(50) DEFAULT NULL,
  `passwd_answer` varchar(255) DEFAULT NULL,
  `last_lon` varchar(20) NOT NULL,
  `last_lat` varchar(20) NOT NULL,
  `openid` varchar(32) NOT NULL,
  `verify_code` int(6) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `openid` (`openid`),
  FULLTEXT KEY `openid_2` (`openid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `cfm_customers`
--

INSERT INTO `cfm_customers` (`user_id`, `email`, `user_name`, `password`, `question`, `answer`, `sex`, `birthday`, `pay_points`, `rank_points`, `address_id`, `reg_time`, `last_login`, `last_time`, `last_ip`, `visit_count`, `salt`, `flag`, `alias`, `qq`, `mobile_phone`, `is_validated`, `passwd_question`, `passwd_answer`, `last_lon`, `last_lat`, `openid`, `verify_code`) VALUES
(1, '', '123456', '', '', '', 0, '0000-00-00', 0, 0, 0, 0, 0, '0000-00-00 00:00:00', '', 0, NULL, 0, '', '', '', 0, NULL, NULL, '', '', '', 1234),
(2, '', '', '', '', '', 0, '0000-00-00', 0, 0, 0, 0, 0, '0000-00-00 00:00:00', '127.0.0.1', 0, NULL, 0, '', '', '15615386668', 1, NULL, NULL, '', '', 'a7b7f89797ab79a79b', 888708),
(3, '', '', '', '', '', 0, '0000-00-00', 0, 0, 0, 0, 0, '0000-00-00 00:00:00', '127.0.0.1', 0, NULL, 0, '', '', '', 0, NULL, NULL, '', '', 'b14f412bab1234bd12b', NULL),
(4, '', '', '', '', '', 0, '0000-00-00', 0, 0, 0, 0, 0, '0000-00-00 00:00:00', '127.0.0.1', 0, NULL, 0, '', '', '', 0, NULL, NULL, '', '', 'e8e977e7e9789e', NULL),
(5, '', '', '', '', '', 0, '0000-00-00', 0, 0, 0, 0, 0, '0000-00-00 00:00:00', '127.0.0.1', 0, NULL, 0, '', '', '', 0, NULL, NULL, '', '', 'fasoidfhasiodfhasoi', NULL),
(6, '', '', '', '', '', 0, '0000-00-00', 0, 0, 0, 0, 0, '0000-00-00 00:00:00', '211.65.108.27', 0, NULL, 0, '', '', NULL, 0, NULL, NULL, '', '', '34tfwaawe4t3wetfg', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `cfm_feedback`
--

CREATE TABLE IF NOT EXISTS `cfm_feedback` (
  `fback_id` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(11) DEFAULT NULL,
  `role` int(11) DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`fback_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `cfm_options`
--

CREATE TABLE IF NOT EXISTS `cfm_options` (
  `key` varchar(32) NOT NULL,
  `type` varchar(20) NOT NULL,
  `value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `cfm_options`
--

INSERT INTO `cfm_options` (`key`, `type`, `value`) VALUES
('last_history_update', 'date', '2014-03-05');

-- --------------------------------------------------------

--
-- 表的结构 `cfm_order_details`
--

CREATE TABLE IF NOT EXISTS `cfm_order_details` (
  `rec_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `good_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `good_name` varchar(120) NOT NULL DEFAULT '',
  `good_number` smallint(5) unsigned NOT NULL DEFAULT '1',
  `good_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`rec_id`),
  KEY `order_id` (`order_id`),
  KEY `goods_id` (`good_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=53 ;

--
-- 转存表中的数据 `cfm_order_details`
--

INSERT INTO `cfm_order_details` (`rec_id`, `order_id`, `good_id`, `good_name`, `good_number`, `good_price`) VALUES
(8, 2, 2, '', 2, '22.00'),
(7, 2, 1, 'what do you think', 2, '10.00'),
(5, 1, 1, 'what do you think', 2, '10.00'),
(6, 1, 2, '', 2, '22.00'),
(9, 3, 1, 'what do you think', 2, '10.00'),
(10, 3, 2, '', 2, '22.00'),
(11, 4, 1, 'what do you think', 2, '10.00'),
(12, 4, 2, '', 2, '22.00'),
(13, 5, 1, 'what do you think', 2, '10.00'),
(14, 5, 2, '', 2, '22.00'),
(15, 6, 1, 'what do you think', 2, '10.00'),
(16, 6, 2, '', 2, '22.00'),
(17, 7, 1, 'what do you think', 2, '10.00'),
(18, 7, 2, '', 2, '22.00'),
(19, 8, 1, 'what do you think', 2, '10.00'),
(20, 8, 2, '', 2, '22.00'),
(21, 9, 1, 'what do you think', 2, '10.00'),
(22, 9, 2, '', 2, '22.00'),
(23, 10, 1, 'what do you think', 2, '10.00'),
(24, 10, 2, '', 2, '22.00'),
(25, 11, 1, 'what do you think', 2, '10.00'),
(26, 11, 2, '', 2, '22.00'),
(27, 12, 1, 'what do you think', 2, '10.00'),
(28, 12, 2, '', 2, '22.00'),
(29, 13, 1, 'what do you think', 2, '10.00'),
(30, 13, 2, '', 2, '22.00'),
(31, 14, 1, 'what do you think', 2, '10.00'),
(32, 14, 2, '', 2, '22.00'),
(33, 15, 1, 'what do you think', 1, '10.00'),
(34, 16, 1, 'what do you think', 1, '10.00'),
(52, 30, 1, 'what do you think', 1, '10.00'),
(51, 25, 1, 'what do you think', 1, '10.00');

-- --------------------------------------------------------

--
-- 表的结构 `cfm_order_info`
--

CREATE TABLE IF NOT EXISTS `cfm_order_info` (
  `order_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(20) NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL,
  `user_realname` varchar(10) NOT NULL,
  `order_status` tinyint(4) NOT NULL DEFAULT '0',
  `ant_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `confirm_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `taking_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `shipping_status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `pay_status` tinyint(1) NOT NULL DEFAULT '0',
  `ant_id` varchar(60) DEFAULT NULL,
  `ant_time` int(11) DEFAULT NULL,
  `address` varchar(255) NOT NULL,
  `user_phone` varchar(60) NOT NULL,
  `pay_id` tinyint(20) NOT NULL DEFAULT '0',
  `goods_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tips_amount` decimal(10,2) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `disp_id` int(11) DEFAULT NULL,
  `order_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `order_time_ms` varchar(30) DEFAULT NULL,
  `confirm_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `taking_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shipping_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pay_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `add_date` date DEFAULT NULL,
  `nonce` varchar(64) NOT NULL,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `order_sn` (`order_sn`),
  KEY `user_id` (`user_id`),
  KEY `order_status` (`order_status`),
  KEY `shipping_status` (`confirm_status`),
  KEY `pay_status` (`taking_status`),
  KEY `pay_id` (`pay_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- 转存表中的数据 `cfm_order_info`
--

INSERT INTO `cfm_order_info` (`order_id`, `order_sn`, `user_id`, `user_realname`, `order_status`, `ant_status`, `confirm_status`, `taking_status`, `shipping_status`, `pay_status`, `ant_id`, `ant_time`, `address`, `user_phone`, `pay_id`, `goods_amount`, `tips_amount`, `shop_id`, `disp_id`, `order_time`, `order_time_ms`, `confirm_time`, `taking_time`, `shipping_time`, `pay_time`, `add_date`, `nonce`) VALUES
(1, '20142342234', 1, '王尼玛', 1, 1, 0, 0, 1, 1, NULL, NULL, '就不告诉你', '123123', 0, '0.00', '10.00', 1, 0, '2014-04-14 09:49:42', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-04-15 05:38:30', '0000-00-00 00:00:00', NULL, ''),
(2, '20140415040643', 0, '王尼玛', 1, 1, 0, 0, 0, 1, NULL, NULL, '就不告诉你', '123123', 0, '0.00', '10.00', 1, 0, '2014-04-15 05:44:03', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-05-15', ''),
(3, '20140415040746', 0, '王尼玛', 1, 0, 0, 0, 0, 0, '0', NULL, '就不告诉你', '123123', 0, '0.00', '10.00', 1, 0, '2014-04-15 05:45:46', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-05-15', ''),
(4, '20140415040782', 0, '王尼玛', 1, 0, 0, 0, 0, 0, '0', NULL, '就不告诉你', '123123', 0, '0.00', '10.00', 0, 0, '2014-04-15 05:46:22', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-05-15', ''),
(5, '20140415041409', 5, '王尼玛', 0, 0, 0, 0, 0, 1, '0', NULL, '就不告诉你', '123123', 0, '0.00', '10.00', 0, 0, '2014-04-15 05:56:49', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-05-15', ''),
(6, '20140415046073', 5, '王尼玛', 0, 0, 0, 0, 0, 0, '0', NULL, '就不告诉你', '123123', 0, '32.00', '10.00', 0, 0, '2014-04-15 07:14:33', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-05-15', ''),
(10, '20140505004510', 8, '王尼玛', 1, 0, 0, 0, 0, 0, '1', NULL, '就不告诉你', '123123', 0, '32.00', '10.00', 0, 0, '2014-05-05 15:41:50', '0.999999999999999', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-05-13', ''),
(13, '20140507533901698100', 5, '王尼玛', 1, 1, 1, 1, 1, 1, '1', NULL, '就不告诉你', '123123', 0, '32.00', '10.00', 1, 0, '2014-05-24 09:03:10', '1399453390', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-05-25', '8bd7ac66d7b7c7a6d'),
(14, '20140524342545925100', 6, '王尼玛', 1, 0, 0, 0, 0, 0, '1', NULL, '就不告诉你', '123123', 0, '32.00', '10.00', 1, 0, '2014-05-24 12:24:14', '1400934254', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-05-24', '123124124eqw'),
(30, '20140527962407664100', 5, '章', 1, 0, 0, 0, 0, 0, NULL, NULL, 'fa;s ', '18013874721', 0, '10.00', '10.00', 1, NULL, '2014-05-27 13:10:40', '1401196240', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2014-05-27', '1902390213');

-- --------------------------------------------------------

--
-- 表的结构 `cfm_payment`
--

CREATE TABLE IF NOT EXISTS `cfm_payment` (
  `pay_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `ant_id` int(11) NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `creat_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pay_time` timestamp NULL DEFAULT NULL,
  `finished` tinyint(1) NOT NULL DEFAULT '0',
  `check_id` varchar(32) NOT NULL,
  PRIMARY KEY (`pay_id`),
  KEY `user_id` (`user_id`),
  KEY `order_id` (`order_id`),
  KEY `ant_id` (`ant_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `cfm_providers`
--

CREATE TABLE IF NOT EXISTS `cfm_providers` (
  `provider_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(60) NOT NULL DEFAULT '',
  `provider_name` varchar(60) NOT NULL DEFAULT '',
  `password` varchar(32) NOT NULL DEFAULT '',
  `shop_id` int(11) NOT NULL,
  `question` varchar(255) NOT NULL DEFAULT '',
  `answer` varchar(255) NOT NULL DEFAULT '',
  `sex` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `birthday` date NOT NULL DEFAULT '0000-00-00',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_ip` varchar(15) NOT NULL DEFAULT '',
  `visit_count` smallint(5) unsigned NOT NULL DEFAULT '0',
  `user_rank` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `salt` varchar(10) DEFAULT NULL,
  `parent_id` mediumint(9) NOT NULL DEFAULT '0',
  `flag` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `alias` varchar(60) NOT NULL,
  `qq` varchar(20) NOT NULL,
  `mobile_phone` varchar(20) NOT NULL,
  `is_validated` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `credit_line` decimal(10,2) unsigned NOT NULL,
  `passwd_question` varchar(50) DEFAULT NULL,
  `passwd_answer` varchar(255) DEFAULT NULL,
  `last_log` text NOT NULL,
  `last_lat` text NOT NULL,
  `openid` text NOT NULL,
  `channel_id` varchar(32) NOT NULL,
  `channel_user_id` varchar(32) NOT NULL,
  PRIMARY KEY (`provider_id`),
  UNIQUE KEY `user_name` (`provider_name`),
  UNIQUE KEY `user_id` (`provider_id`),
  UNIQUE KEY `email_2` (`email`),
  UNIQUE KEY `mobile_phone` (`mobile_phone`),
  KEY `email` (`email`),
  KEY `parent_id` (`parent_id`),
  KEY `flag` (`flag`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `cfm_providers`
--

INSERT INTO `cfm_providers` (`provider_id`, `email`, `provider_name`, `password`, `shop_id`, `question`, `answer`, `sex`, `birthday`, `reg_time`, `last_login`, `last_time`, `last_ip`, `visit_count`, `user_rank`, `salt`, `parent_id`, `flag`, `alias`, `qq`, `mobile_phone`, `is_validated`, `credit_line`, `passwd_question`, `passwd_answer`, `last_log`, `last_lat`, `openid`, `channel_id`, `channel_user_id`) VALUES
(1, '', 'xm1994', 'e10adc3949ba59abbe56e057f20f883e', 1, '', '', 0, '0000-00-00', 0, 0, '0000-00-00 00:00:00', '211.65.108.22', 0, 0, NULL, 0, 0, '', '', '', 0, '0.00', NULL, NULL, '', '', '', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `cfm_shop`
--

CREATE TABLE IF NOT EXISTS `cfm_shop` (
  `shop_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner_id` int(11) DEFAULT NULL,
  `shop_name` varchar(255) NOT NULL,
  `shop_desc` varchar(512) DEFAULT NULL,
  `shop_pos` text,
  `shop_phone` varchar(13) DEFAULT NULL,
  `pic_url` text,
  `shop_lon` text,
  `shop_lat` text,
  `isopen` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`shop_id`),
  UNIQUE KEY `shop_id` (`shop_id`),
  UNIQUE KEY `owner_id` (`owner_id`),
  KEY `shop_id_2` (`shop_id`),
  KEY `owner_id_2` (`owner_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `cfm_shop`
--

INSERT INTO `cfm_shop` (`shop_id`, `owner_id`, `shop_name`, `shop_desc`, `shop_pos`, `shop_phone`, `pic_url`, `shop_lon`, `shop_lat`, `isopen`) VALUES
(1, 1, '测试商店1', '这就是一个测试商店', '他位于位置1', '123456789', 'http://www.baidu.com/1/pic', NULL, NULL, 1),
(2, 2, '测试商店2', '这就是一个测试商店', '他位于位置2', '123456779', 'http://www.baidu.com/1/pic', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- 表的结构 `cfm_shop_goods`
--

CREATE TABLE IF NOT EXISTS `cfm_shop_goods` (
  `good_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `shop_id` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `onsale` tinyint(1) NOT NULL DEFAULT '0',
  `pic_url` text NOT NULL,
  `good_name` varchar(64) NOT NULL,
  `good_desc` text NOT NULL,
  `unavail` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`good_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `cfm_shop_goods`
--

INSERT INTO `cfm_shop_goods` (`good_id`, `shop_id`, `price`, `onsale`, `pic_url`, `good_name`, `good_desc`, `unavail`) VALUES
(1, 1, '10.00', 0, '0', 'what do you think', '你猜我猜不猜', 0),
(2, 1, '22.00', 0, '', '', '', 0);

-- --------------------------------------------------------

--
-- 表的结构 `cfm_tokens`
--

CREATE TABLE IF NOT EXISTS `cfm_tokens` (
  `token` varchar(32) NOT NULL,
  `id` int(11) NOT NULL,
  `role` int(11) NOT NULL,
  `gen_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token`),
  UNIQUE KEY `token` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `cfm_tokens`
--

INSERT INTO `cfm_tokens` (`token`, `id`, `role`, `gen_time`) VALUES
('177a8b7514ee3d19010f9f496b3fcba7', 2, 102, 2147483647),
('22ed3fe7cb42c583a25ffc47b69e4700', 1, 103, 1401173771),
('4748494df69b0430dc0d6b46f40b2a7b', 3, 102, 2147483647),
('5779ef79bed5c04ad78c703008eb7431', 4, 102, 1397469629),
('83dd07daefd9f93f8b2283376456879e', 0, 103, 2147483647),
('aa577b671b83e57ddd6e743f5682bf41', 5, 102, 2000000000),
('b85361bdc1f2bb73d9837f56a0f59d37', 6, 102, 1400934213),
('ba451e22041dc78efead4b1e42fb388b', 1, 101, 1401195939),
('f4ff4ed889d37df55db153c2f85efc18', 1, 102, 2147483647);

-- --------------------------------------------------------

--
-- 表的结构 `cfm_user_address`
--

CREATE TABLE IF NOT EXISTS `cfm_user_address` (
  `addr_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_realname` text NOT NULL,
  `user_phone` varchar(13) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `address` text NOT NULL,
  `user_lon` text NOT NULL,
  `user_lat` text NOT NULL,
  PRIMARY KEY (`addr_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `cfm_user_address`
--

INSERT INTO `cfm_user_address` (`addr_id`, `user_realname`, `user_phone`, `user_id`, `address`, `user_lon`, `user_lat`) VALUES
(1, '张三', '15615615615', 1, '我就不告诉你我在哪儿日', '', ''),
(3, '曾宪文', '12345678901', 2, '怡园16栋601-01', '', ''),
(4, '章', '18013874721', 5, 'fa;s ', '', ''),
(5, '王尼玛', '123123', 6, '就不告诉你', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `cfm_verify_code`
--

CREATE TABLE IF NOT EXISTS `cfm_verify_code` (
  `mobile_phone` int(11) NOT NULL,
  `verify_code` int(11) NOT NULL,
  `role` int(11) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
